# Copyright

- Copyright (c) [2009](https://github.com/mockery/mockery/commit/1d96f88142abe804ab9e893a5f07933f63e9bff9), [Pádraic Brady](https://github.com/padraic) <padraic.brady@gmail.com>
- Copyright (c) [2011](https://github.com/mockery/mockery/commit/94dbb63aab37c659f63ea6e34acc6958928b0f59), [Robert Basic](https://github.com/robertbasic) <robertbasic.com@gmail.com>
- Copyright (c) [2012](https://github.com/mockery/mockery/commit/64e3ad6960eb3202b5b91b91a4ef1cf6252f0fef), [Dave Marshall](https://github.com/davedevelopment) <dave.marshall@atstsolutions.co.uk>
- Copyright (c) [2013](https://github.com/mockery/mockery/commit/270ddd0bd051251e36a5688c52fc2638a097b110), [Graham Campbell](https://github.com/GrahamCampbell) <hello@gjcampbell.co.uk>
- Copyright (c) [2017](https://github.com/mockery/mockery/commit/ba28b84c416b95924886bbd64a6a2f68e863536a), [Nathanael Esayeas](https://github.com/ghostwriter) <nathanael.esayeas@protonmail.com>
