<?php

namespace Faker\Provider\fr_CH;

class Color extends \Faker\Provider\fr_FR\Color
{
}
